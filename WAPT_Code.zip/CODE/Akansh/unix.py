import hashlib
import sys
print("""\033[36m]
	 ▄  █ ██      ▄▄▄▄▄    ▄  █     ▄█▄    ████▄ ██▄   ▄███▄   
	█   █ █ █    █     ▀▄ █   █     █▀ ▀▄  █   █ █  █  █▀   ▀  
	██▀▀█ █▄▄█ ▄  ▀▀▀▀▄   ██▀▀█     █   ▀  █   █ █   █ ██▄▄    
	█   █ █  █  ▀▄▄▄▄▀    █   █     █▄  ▄▀ ▀████ █  █  █▄   ▄▀ 
	   █     █               █      ▀███▀        ███▀  ▀███▀   
	  ▀     █               ▀                               
	       ▀                             
""")
A = True
while A:
    print("Enter your choice \n 1. To encrypt your data \n 2. To decrypt your data")
    choice = int(input())
    if choice == 1:
        print("Select your choice to encrypt your data in which format \n 1.MD5 \n 2.SHA1 \n 3.SHA224 \n 4.SHA256 \n "
              "5.SHA384 \n 6.512 \n 7.Quit")
        sub_choice = int(input())
        if sub_choice == 1:
            string = input("Enter a string that you want to encrypt: ")
            hashobj1 = hashlib.md5()
            hashobj1.update(string.encode())
            print(hashobj1.hexdigest())
        elif sub_choice == 2:
            string = input("Enter a string that you want to encrypt: ")
            hashobj2 = hashlib.sha1()
            hashobj2.update(string.encode())
            print(hashobj2.hexdigest())
        elif sub_choice == 3:
            string = input("Enter a string that you want to encrypt: ")
            hashobj3 = hashlib.sha224()
            hashobj3.update(string.encode())
            print((hashobj3.hexdigest()))
        elif sub_choice == 4:
            string = input("Enter a string that you want to encrypt: ")
            hashobj4 = hashlib.sha256()
            hashobj4.update(string.encode())
            print((hashobj4.hexdigest()))
        elif sub_choice == 5:
            string = input("Enter a string that you want to encrypt: ")
            hashobj5 = hashlib.sha384()
            hashobj5.update(string.encode())
            print((hashobj5.hexdigest()))
        elif sub_choice == 6:
            string = input("Enter a string that you want to encrypt: ")
            hashobj6 = hashlib.sha512()
            hashobj6.update(string.encode())
            print((hashobj6.hexdigest()))
        elif sub_choice == 7:
            A = False
    if choice == 2:
        print("Select your choice to decrypt your data in which format \n 1.MD5 \n 2.SHA1 \n 3.SHA224 \n 4.SHA256 \n "
              "5.SHA384 \n 6.512 \n 7.Quit")
        sub_choice = int(input())
        if sub_choice == 1:
            string = input("Enter a string that you want to decrypt: ")